export * from './colors';
export * from './filter';
export * from './font';
export * from './margins';
export * from './paddings';
export * from './shadows';
//# sourceMappingURL=index.d.ts.map